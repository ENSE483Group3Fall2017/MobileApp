package e.f.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void regiesterPet(View view) {

        Intent RP = new Intent(getApplicationContext(), RegisterPet.class);
        startActivity(RP);
    }

    public void lostPet(View view) {

        Intent LP = new Intent(getApplicationContext(), LostPet.class);
        startActivity(LP);
    }

    public void SearchPet(View view) {

        Intent SP = new Intent(getApplicationContext(), SearchPet.class);
        startActivity(SP);
    }


}
